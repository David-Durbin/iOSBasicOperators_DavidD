//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

// section 1, variables

var add = 0
var sub = 0
var mult = 0.0
var div = 0.0
var perc = 0.0

// section 1.1, constants    // Incedently, things in swift are seperated by commas not semicolons
let x = 42, y = 84
let pi = 3.14159, z = 25.0, pct = 0.25


// Section 2, operations

add = x + y //addition

sub = y - x // subtration

mult = pi * z // multiplication

div = z / pi // division

perc = z * pct  // percentage


// Section 3, output

print("Calculating ", x, " + ", y, " = ", add ) // print addition
print("Calculating ", y, " - ", x, " = ", sub) // print subtraction
print("Calculating ", pi, " * ", z, " = ", mult) // print multiplication
print("Calculating ", z, " / ", pi, " = ", div) // print division
print("Calculating ", z, " * ", pct, " = ", perc) // print percentage






